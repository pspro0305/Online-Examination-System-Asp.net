Project Name: Online Examination System
Made By: Prakhar Srivastava

Project Discription: In this project, we are going to make an online exam system where an admin can take exam for the current student who are logged in this system. 
Here admin can insert update and delete the exam category, subject, exam, exam question. Each item, relate with each other. So if the admin delete the exam then the question under this exam will automatically delete. Besides, admin can also see all the result in this system as well as specific student result and student list. He can add the admin, reset the password and so on.
In student module student can easilt show the exam category, subject which automatically filter the exam under this and there is no need of authenticate. In order to give the he/she must be logged in. To login a user need name, mail and password to register. If the register email is already use he/she can use it. By login a user can see his result as well as marks and given exam name, date and so on.
This application is fully responsive.


Database : There all file of the database in folder execute accordingly.
